Completed exercises 4,5,6 and 7.
All files should be named as the examples in the virtual campus.
