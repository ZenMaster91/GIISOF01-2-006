All exercises had been finished, I thought we had to do for home until 14 so in class only investigate and tryed to solve 15.
Also tried to fix the issues commented by the teacher in the first deliverable.
