#ifndef SIMULADOR_H
#define SIMULADOR_H


// General constants for the simulation

// Maximum number of user programs in the command line
#define USERPROGRAMSMAXNUMBER 20


#endif
